<a href="{{$script ? 'javascript:void(0);' : $url }}" {!! $linkattribute !!}>
    <i class="fa {{$icon}}" {!! $iconattribute !!}></i>
</a>